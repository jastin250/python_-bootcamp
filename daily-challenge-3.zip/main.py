'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
from tkinter import *
import tkinter.messagebox
root =Tk()
root.title("Employee Registration form")
root.geometry('600x300')
root.configure(background = "voilet90")

label1= Label(root ,text="Employee Registration Form", font=("bold",30)).grid(row =0, column=2)
Firstname = Label(root ,text ="First Name",width=30,font=("bold",20)).grid(row = 1,column = 1)
Middlename = Label(root ,text ="Middle Name",width=30,font=("bold",20)).grid(row =2,column = 1)
Lastname = Lable(root, text ="Last Name",width=30,font=("bold",20)).grid(row =3,column= 1)
Fathername = Lable(root, text ="Father Name",width=30,font=("bold",20)).grid(row =4,column= 1)
Address = Lable(root, text ="Address",width=30,font=("bold",20)).grid(row =5,column= 1)
City = Lable(root, text ="City",width=30,font=("bold",20)).grid(row  =6,column= 1)
State = Lable(root, text ="State",width=30,font=("bold",20)).grid(row  =7,column= 1)
Country = Lable(root, text ="Country",width=30,font=("bold",20)).grid(row =8,column= 1)
list1 = ['America','canada','India','New zealand','Japan'];
c=StringVar()
droplist=OptionMenu(root,c, *list1)
droplist.config(width=20)
c.set('Select your country')
droplist.grid(row= 8,column=2)
Mobile = Lable(root,text ="Contact Number",width=30,font=("bold",20)).grid(row =9,column = 1)
Email = Lable(root,text ="Email ID",width=30,font=("bold",20)).grid(row =10,column = 1)
Gender = Lable(root,text ="Gendet",width=30,font=("bold",20)).grid(row =11,column = 1)
var = IntVar()
Radiobutton(root, text="Male",padx = 40, variable=var, value=1).grid(row =12,column = 2)
Radiobutton(root, text="Female",padx = 40, variable=var, value=1).grid(row =12,column = 3)
 
Firstname1 = Entry(root).grid(row = 1,column = 2)
Middlename = Entry(root).grid(row = 2,column = 2)
Lastname = Entry(root).grid(row = 3,column = 2)
Fathername = Entry(root).grid(row = 4,column = 2)
Address1 = Entry(root).grid(row = 5,column = 2)
City1 = Entry(root).grid(row = 6,column = 2)
State1 = Entry(root).grid(row = 7,column = 2)
country1 = Entry(root).grid(row = 8,column = 2)
Mobile1 = Entry(root).grid(row = 9,column = 2)
Email1 = Entry(root).grid(row = 10,column = 2)

def onClick():
    tkinter.messagebox.showinfo("Welcome", "Your Details Submitted Successfully !")

# create a Button
Button(root, text="Submit", command=onClick,width=30,bg="orange",fg='blue').grid(row = 15,column = 2)
 
 
root.mainloop()
